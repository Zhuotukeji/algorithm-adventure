# 算法小冒险 (Algorithm Adventure)

![License](https://img.shields.io/badge/license-MIT-blue.svg)
![React](https://img.shields.io/badge/React-18-blue)
![TypeScript](https://img.shields.io/badge/TypeScript-5-blue)

为10岁儿童设计的C++和算法编程学习平台。通过游戏化方式，让孩子在冒险闯关中学习编程。

## ✨ 特性

- 🎮 **游戏化学习** - 角色扮演冒险，升级解锁新技能
- 📚 **完整课程体系** - 从Hello World到排序算法
- 🎨 **可视化编辑器** - 儿童友好型C++代码编辑器
- 🔮 **算法可视化** - 动态展示排序、搜索算法执行过程
- 👨‍👩‍👧 **家长监护** - 查看学习进度和成就

## 🚀 快速开始

### 安装依赖

```bash
npm install
# 或
pnpm install
```

### 开发模式

```bash
npm run dev
```

访问 http://localhost:5173

### 构建生产版本

```bash
npm run build
```

### 本地预览

```bash
npm run preview
```

## 📁 项目结构

```
algorithm-adventure/
├── src/
│   ├── components/     # React组件
│   ├── context/       # 状态管理
│   ├── data/          # 课程数据
│   ├── pages/         # 页面组件
│   ├── types/         # TypeScript类型
│   └── App.tsx        # 主应用
├── public/            # 静态资源
└── dist/              # 构建输出
```

## 🎯 课程章节

| 章节 | 主题 | 关卡数 |
|------|------|--------|
| 第1章 | 魔法入门（变量、输出） | 3 |
| 第2章 | 魔法咒语格式（输入输出） | 2 |
| 第3章 | 简单的魔法（条件判断） | 2 |
| 第4章 | 循环魔法（for循环） | 2 |
| 第5章 | 数组宝库 | 2 |
| 第6章 | 排序秘籍（冒泡排序） | 1 |

## 🛠️ 技术栈

- React 18 + TypeScript
- Vite 构建工具
- Tailwind CSS
- React Router
- Lucide Icons

## 📝 使用说明

1. 在地图界面选择关卡
2. 阅读NPC任务描述
3. 在代码编辑器中编写C++代码
4. 点击"运行代码"测试
5. 通关后获得经验值和魔法石

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📄 许可证

MIT License
